$(document).ready(function(){

	// action on form submit
	$(".import").on("submit",function(e){
		e.preventDefault();
		
		var file = $(".import-file").val();
			// check file empty 
			if(file == "" || file == null)
			{
				// alert("file can not Empty");
				  toastr.options.timeOut = 2500; // 1.5s
                      toastr.error('File can not empty');
			}
			else
			{

				 var fileExtension = ['xlsx','xls'];
                // file validation 
                if ($.inArray($(".import-file").val().split('.').pop().toLowerCase(), fileExtension) == -1){
                     // alert("Only formats are allowed : "+fileExtension.join(', '));
     			  toastr.options.timeOut = 2500; // 1.5s
	                 toastr.error("Only formats are allowed : "+fileExtension.join(', '));

                   }
                   else
                   {
                   	// start ajax 
                   		$.ajaxSetup({
						headers :{
							'X-CSRF-TOKEN': $("body").attr("token")
						}
						});

                   	$.ajax({
	                    type:"POST",
	                    url:"/file-import",
	                    data : new FormData(this),
	                    contentType:false,
	                    processData:false,
	                    beforeSend: function() {
				        // setting a timeout
				        $('.submit').css('display','none');
				        $('.loading').css('display','block');

				        
				    },
	                    success:function(result)
	                    {
	                     	if($.trim(result) == "done")
	                     	{
	                     		setTimeout(function() {
                                		location.reload();
                            		}, 2000);
                                            
                                 toastr.options.timeOut = 2500; // 1.5s
                                 toastr.success('File Import Successfully');
	                     	}  
	                     	else
	                     	{
	                     		alert(result);
	                     	} 
	                    }
	   		
	        		});
                   	 	
                   	// end ajax
                   }
			}
	})
})