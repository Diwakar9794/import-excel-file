<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Import Excel File</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">

    <script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="../js/script.js?catch=<?php echo time(); ?>"></script>

    <script src="http://code.jquery.com/jquery-1.9.1.min.js"></script>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.0.1/css/toastr.css" rel="stylesheet"/>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.0.1/js/toastr.js"></script>
</head>

<body token="<?php echo e(csrf_token()); ?>">
    <div class="container mt-5 ">
        <div class="card-header">
            <h2 class="mb-4">Import Excel File to Database </h2>    
        </div>
        
        <div class="card-body">
            <form class="import" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>   
                <label class="form-label mb-2">Choose Excel File</label>
                <input type="file" name="file" class="import-file form-control">
                <button class="btn btn-primary mt-3 submit">Submit</button>
            </form>
                
                <button class="btn btn-secondary loading mt-3" disabled style="display: none;">File Importing... please wait.</button>

        </div>    
    </div>
</body>
</html><?php /**PATH D:\laravel project\import_data\resources\views/file-import.blade.php ENDPATH**/ ?>